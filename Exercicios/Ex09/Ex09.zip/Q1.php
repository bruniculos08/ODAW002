<?php
    echo "Hoje é ";
    echo date("d/m/Y");
    echo "e agora são ";
    // "." serve para concatenar strings:
    echo date("H:i")."h\n";
?>