<!DOCTYPE HTML>
<html>  
<body>
<style>
.error {color: #FF0000;}
</style>

<?php
    session_start();
?>

<p>
Banco de Dados - página inicial
    <br>
        <a href="Q1_inserir.php"> Inserir cadastro(s) </a>
    <br>
        <a href="Q1_mostrar.php"> Mostrar cadastro(s) efetuado(s) </a>
    <br>
        <a href="Q1_alterar.php"> Alterar cadastro(s) </a>
    <br>
        <a href="Q1_deletar.php"> Excluir cadastro(s) </a>
    <br>
</p>

</body>
</html>