<?php
    $conexao = new mysqli("localhost","udesc","udesc","petshop");
    if ($conexao -> connect_errno) {
        die('Não foi possível conectar: ' . $conexao -> connect_error);
    }
    echo 'Conexão bem sucedida <br>';
    
    $id = $_POST['id'];
    $name = $_POST["name"];
    $breeds = $_POST["breeds"];
    
    echo strval($id) . strval(empty($name)) . strval(empty($breeds)) . '<br>';

    if(empty($id) or (empty($name) and empty($breeds))) {
        echo "<br> Você deve preencher o campo id e pelo menos um dos campos novo nome ou nova raça </br>";
        include "Q1_alterar.php";
    } else {
        if(!empty($name) and !empty($breeds)) {
            $query = "UPDATE dogs SET nome=$name, breeds=$breeds WHERE id=$id";
        } else if(!empty($name)) {
            $query = "UPDATE dogs SET nome=$name WHERE id=$id";
        } else if(!empty($breeds)) {
            $query = "UPDATE dogs SET breeds=$breeds WHERE id=$id";
        }
        echo $query;
        mysqli_query($conexao, $query);
        mysqli_close($conexao);
        header("Location: Q1_mostrar.php");
    }  
?>